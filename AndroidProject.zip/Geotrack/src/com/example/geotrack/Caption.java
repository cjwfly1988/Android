package com.example.geotrack;
/*
 * Helper-class for the captions of the main menu.
 */
public class Caption {
	static String[] Headlines = {
		"Mapview",
		"Listview"
		};
}
